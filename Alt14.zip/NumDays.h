#pragma once
#ifndef NumDays_H
#define NumDays_H
#include <iostream>
using namespace std;

//The NumDays class
class NumDays
{
private:
	int hours;   //the hours
	double days;  //the days
public:
	//Constructor
	NumDays(int);

	//Setter functions
	void setHours(int);
	void setDays(int);

	//Getter functions
	int getHours();
	double getDays();

	//Operator overloading members
	int operator+ (const NumDays &right);
	int operator- (const NumDays &right);
	NumDays operator++();
	NumDays operator++(int);
	NumDays operator--();
	NumDays operator--(int);
	
};

#endif // !NumDays_H