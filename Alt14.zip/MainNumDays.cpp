//Main file
#include "NumDays.h"
#include <iostream>
using namespace std;

int main()
{
	//hours variables
	int hours1, hours2;
	//Program greeting
	cout << "Welcome to the Days/Hours Converter Program.\n";
	cout << "Please enter how many hours you have worked: ";
	cin >> hours1 >> hours2;

	//Create two instances of the NumDays class
	NumDays one(hours1), two(hours2);

	//Displays the number of days worked 
	cout << "ONE: " << one.getDays() << " days." << endl;
	cout << "TWO: " << two.getDays() << " days." << endl;

	//Use the prefix increment operator
	one = ++two;
	cout << "ONE: " << one.getDays() << " days." << endl;
	cout << "TWO: " << two.getDays() << " days." << endl;

	//Use the postfix increment operator
	one = two++;
	cout << "ONE: " << one.getDays() << " days." << endl;
	cout << "TWO: " << two.getDays() << " days." << endl;

	//Use the prefix decrement operator
	one = --two;
	cout << "ONE: " << one.getDays() << " days." << endl;
	cout << "TWO: " << two.getDays() << " days." << endl;

	//Use the postfix decrement operator
	one = two--;
	cout << "ONE: " << one.getDays() << " days." << endl;
	cout << "TWO: " << two.getDays() << " days." << endl;

	system("pause");
	return 0;
}