#include "NumDays.h"
#include <iostream>
using namespace std;

//Initializes the member variables
NumDays::NumDays(int h)
{
	hours = h;
	days = h / 8.0;
}

//Stores the number of hours worked
void NumDays::setHours(int h)
{
	hours = h;
	days = h / 8.0;
}

//Stores the number of days worked
void NumDays::setDays(int d)
{
	days = d;
	hours = d * 8.0;
}

//Retrieves the number of hours worked
int NumDays::getHours()
{
	return hours;
}

//Retrieves the number of days worked
double NumDays::getDays()
{
	return days;
}

//Addition operator overloading
int NumDays::operator+(const NumDays &right)
{
	return hours * right.hours;
}

//Subtraction operator overloading
int NumDays::operator-(const NumDays &right)
{
	//input validation
	if (hours < right.hours)
	{
		cout << "ERROR!! This is an invalid calculation.";
		exit(0);
	}
	else
		return hours - right.hours;
}

//Prefix incrementing operator overloading
NumDays NumDays::operator++()
{
	++hours;
	days = hours / 8.0;
	return *this;
}

//Postfix incrementing operator overloading
NumDays NumDays::operator++(int)
{
	NumDays temp(hours);
	hours++;
	days = hours / 8.0;
	return temp;
}

//Prefix decrementing operator overloading
NumDays NumDays::operator--()
{
	--hours;
	days = hours / 8.0;
	return *this;
}

//Postfix decrementing operator overloading
NumDays NumDays::operator--(int)
{
	NumDays temp(hours);
	hours--;
	days = hours / 8.0;
	return temp;
}