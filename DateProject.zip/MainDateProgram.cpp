//This is the main program which outputs the date format
#include <iostream>
#include "Date.h"

using namespace std;


int main()
{
	//initialize the variables
	int dayOfYear = 0;
	int monthOfYear = 0; 
	int Year = 0;

	//Greeting
	cout << "Welcome to the Date formatting program.\n";
	cout << "Please enter the day: ";
	cin >> dayOfYear;

	//input validation
	while (dayOfYear < 1 || dayOfYear > 31)
	{
		cout << "ERROR! This is not a valid value for the day\n";
		cout << "Please enter the day again: ";
		cin >> dayOfYear;
	}

	cout << "Please enter the month: ";
	cin >> monthOfYear;
	//input validation
	while (monthOfYear < 1 || monthOfYear > 12)
	{
		cout << "ERROR! This is not a valid value for the month\n";
		cout << "Please enter the month again: ";
		cin >> monthOfYear;
	}

	cout << "Please enter the year: ";
	cin >> Year;

	//Create an instance of the Date class
	Date date(dayOfYear, monthOfYear, Year);

	date.setDay(dayOfYear);
	date.setMonth(monthOfYear);
	date.setYear(Year);

	//output the date
	date.format1();
	date.format2();
	date.format3();

	system("pause");
	return 0;
}