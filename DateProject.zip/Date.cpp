//File which has the class definitions and method definitions
#include <iostream>
#include "Date.h"
#include <string>
using namespace std;

//set the constructor to the day, month and year from the private members
Date::Date(int d, int m, int y)
{
	day = d;
	month = m;
	year = y;
}

//setter for the day
void Date::setDay(int d)
{
	day = d;
}

//setter for the month
void Date::setMonth(int m)
{
	month = m;
}

//setter for the year
void Date::setYear(int y)
{
	year = y;
}

//returns the day value
int Date::getDay()
{
	return day;
}

//returns the month value
int Date::getMonth()
{
	return month;
}

//returns the year value
int Date::getYear()
{
	return year;
}

//formats the date in MM/DD/YYYY form
void Date::format1()
{
	cout << month << "/" << day << "/" << year;
	cout << endl;
}

//formats the date in MonthName/DD/YYYY
void Date::format2()
{
	cout << monthNames[month-1] << " " << day << " " << year;
	cout << endl;
}

//formats the date in DD/MonthName/YYYY
void Date::format3()
{
	cout << day << " " << monthNames[month - 1] << " " << year;
	cout << endl;
}