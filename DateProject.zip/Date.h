//Header file which includes the class declaration for the date
#pragma once
#ifndef DATE
#define DATE_H
#include <iostream>
#include <string>
using namespace std;

class Date
{
private:
	int day; //The day
	int month; //The month
	int year; //The year
	string monthNames[12] = { "January", "February", "March", 
		                     "April", "May", "June", "July", 
		                     "August", "September", "October", "November", "December"};
public:
	//Constructor
	Date(int, int, int);

	//setter methods
	void setDay(int);
	void setMonth(int);
	void setYear(int);

	//getter methods
	int getDay();
	int getMonth();
	int getYear();

	//formatting methods
	void format1();
	void format2();
	void format3();
};

#endif // !Date

